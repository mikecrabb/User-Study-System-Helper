
function loadquestion() {
document.write("<p>My First JavaScript</p>")
}